<span <?php echo e($attributes->class('ql-formats')); ?>>
    <?php echo e($slot); ?>

</span>
<?php /**PATH /home/mjstackc/mj-stack/vendor/rawilk/filament-quill/src/../resources/views/components/toolbar-group.blade.php ENDPATH**/ ?>