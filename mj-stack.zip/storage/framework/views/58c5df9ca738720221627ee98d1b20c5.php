<span <?php echo e($attributes->class('ql-formats')); ?>>
    <?php echo e($slot); ?>

</span>
<?php /**PATH F:\fenohery\mjstack\mj-stack\vendor\rawilk\filament-quill\resources\views\components\toolbar-group.blade.php ENDPATH**/ ?>