<?php
    use Filament\Support\Facades\FilamentAsset;
    use Filament\Support\Facades\FilamentView;
    use Rawilk\FilamentQuill\FilamentQuillServiceProvider;

    $id = $getId();
    $statePath = $getStatePath();
    $isDisabled = $isDisabled();
    $headers = $getHeaders();
    $fonts = $getFonts();
    $fontSizes = $getFontSizes();
    $defaultFontSize = $getDefaultFontSize();
    $defaultHeaderSize = $getDefaultHeaderSize();
    $textChangeHandler = $getOnTextChangeHandler();
    $onInitCallback = $getOnInitCallback();
    $hasHistory = $hasToolbarButton([\Rawilk\FilamentQuill\Enums\ToolbarButton::Undo, \Rawilk\FilamentQuill\Enums\ToolbarButton::Redo]);
    $hasStickyToolbar = $hasStickyToolbar();

    // To make our `prefer-lowest` tests pass, we're checking if the panel has `spa` mode enabled
    // here like this instead, since some earlier versions of filament 3.0 don't appear
    // to have this method defined.
    $hasSpaMode = rescue(fn () => FilamentView::hasSpaMode(), fn () => false);

    $fontSizeStyle = filled($fontSizes)
        ? [
            '--ql-default-size: ' . $defaultFontSize,
        ]
        : [];
?>

<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getFieldWrapperView()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => $field]); ?>
    <div
        style="<?php echo \Illuminate\Support\Arr::toCssStyles([
            ...$fontSizeStyle,
        ]) ?>"
        x-data

        <?php if($shouldLoadStyles()): ?>
            x-load-css="[<?php echo \Illuminate\Support\Js::from(FilamentAsset::getStyleHref('quill', package: FilamentQuillServiceProvider::PACKAGE_ID))->toHtml() ?>]"
            data-css-before="filament"
        <?php endif; ?>
    >
        <?php if($isDisabled): ?>
            <div
                x-data="{
                    state: $wire.<?php echo e($applyStateBindingModifiers("\$entangle('{$statePath}')")); ?>,
                }"
                x-html="state"
                class="fi-quill fi-disabled quill-content prose max-w-none dark:prose-invert block w-full rounded-lg bg-gray-50 px-3 py-3 shadow-sm ring-1 ring-gray-950/10 dark:bg-transparent dark:ring-white/10 text-gray-500 dark:text-gray-400"
            ></div>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal505efd9768415fdb4543e8c564dad437 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal505efd9768415fdb4543e8c564dad437 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.input.wrapper','data' => ['valid' => ! $errors->has($statePath),'attributes' => 
                    \Filament\Support\prepare_inherited_attributes($getExtraAttributeBag())
                        ->class(['fi-quill max-w-full'])
                ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::input.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['valid' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(! $errors->has($statePath)),'attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(
                    \Filament\Support\prepare_inherited_attributes($getExtraAttributeBag())
                        ->class(['fi-quill max-w-full'])
                )]); ?>
                <div
                    <?php if($hasSpaMode): ?>
                        ax-load="visible"
                    <?php else: ?>
                        ax-load
                    <?php endif; ?>
                    ax-load-src="<?php echo e(FilamentAsset::getAlpineComponentSrc('quill', package: FilamentQuillServiceProvider::PACKAGE_ID)); ?>"
                    x-data="quill({
                        state: $wire.<?php echo e($applyStateBindingModifiers("\$entangle('{$statePath}')", isOptimisticallyLive: false)); ?>,
                        statePath: '<?php echo e($statePath); ?>',
                        placeholder: <?php echo \Illuminate\Support\Js::from($getPlaceholder())->toHtml() ?>,
                        options: <?php echo \Illuminate\Support\Js::from($getQuillOptions())->toHtml() ?>,
                        handlers: {
                            <?php $__currentLoopData = $getHandlers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $handlerKey => $handler): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo \Illuminate\Support\Js::from($handlerKey)->toHtml() ?>: <?php echo e($handler); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        },
                        <?php if(filled($textChangeHandler)): ?>
                            onTextChangedHandler: <?php echo e($textChangeHandler); ?>,
                        <?php endif; ?>
                        <?php if(filled($onInitCallback)): ?>
                            onInit: <?php echo e($onInitCallback); ?>,
                        <?php endif; ?>
                        wireId: <?php echo \Illuminate\Support\Js::from($this->getId())->toHtml() ?>,
                        allowImages: <?php echo \Illuminate\Support\Js::from($hasToolbarButton(\Rawilk\FilamentQuill\Enums\ToolbarButton::Image))->toHtml() ?>,
                        hasHistory: <?php echo \Illuminate\Support\Js::from($hasHistory)->toHtml() ?>,
                        stickyToolbar: <?php echo \Illuminate\Support\Js::from($hasStickyToolbar)->toHtml() ?>,
                    })"
                    <?php if($hasHistory): ?>
                        x-on:quill-history-clear.window="clearHistory"
                    <?php endif; ?>
                    x-ignore
                    data-quill-id="<?php echo e($statePath); ?>"
                    <?php if($isLiveDebounced()): ?>
                        x-on:input.debounce.<?php echo e($getLiveDebounce()); ?>="$wire.call('$refresh')"
                    <?php endif; ?>
                    <?php echo e($getExtraAlpineAttributeBag()); ?>

                    style="<?php echo \Illuminate\Support\Arr::toCssStyles([
                        "--ql-min-height: {$getMinHeight()}",
                    ]) ?>"
                >
                    <?php echo $__env->make('filament-quill::partials.toolbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="quill-content" wire:ignore>
                        <div x-ref="quill" id="<?php echo e($id); ?>"></div>
                    </div>

                    <input type="hidden" name="<?php echo e($getName()); ?>" x-bind:value="state">
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal505efd9768415fdb4543e8c564dad437)): ?>
<?php $attributes = $__attributesOriginal505efd9768415fdb4543e8c564dad437; ?>
<?php unset($__attributesOriginal505efd9768415fdb4543e8c564dad437); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal505efd9768415fdb4543e8c564dad437)): ?>
<?php $component = $__componentOriginal505efd9768415fdb4543e8c564dad437; ?>
<?php unset($__componentOriginal505efd9768415fdb4543e8c564dad437); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH F:\fenohery\mjstack\mj-stack\vendor\rawilk\filament-quill\resources\views\quill-editor.blade.php ENDPATH**/ ?>