

<?php $__env->startSection('title'); ?>
    <?php echo e($article->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container pt-32 mx-auto px-4 py-8 max-w-5xl">
    <article class="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden transition-all duration-300 hover:shadow-3xl">
        <?php if($article->featured_image): ?>
            <div class="relative h-[500px]">
                <img src="<?php echo e(Storage::url($article->featured_image)); ?>" 
                     alt="<?php echo e($article->title); ?>"
                     class="w-full h-full object-cover transition-transform duration-300 hover:scale-105">
                <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            </div>
        <?php endif; ?>
        
        <div class="p-10">
            <!-- Tags -->
            <div class="flex flex-wrap gap-2 mb-8">
                <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="px-4 py-1.5 text-sm font-medium rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300 transition-colors duration-200 hover:bg-blue-200 dark:hover:bg-blue-900">
                        <?php echo e($tag->name); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Title -->
            <h1 class="text-5xl font-bold mb-8 text-gray-900 dark:text-white leading-tight"><?php echo e($article->title); ?></h1>

            <!-- Article Meta -->
            <div class="flex flex-wrap items-center gap-6 mb-8 text-sm text-gray-600 dark:text-gray-400">
                <span class="flex items-center transition-colors duration-200 hover:text-blue-500">
                    <i class="far fa-calendar mr-2"></i>
                    <?php if($article->published_at !== null): ?>
                        <?php echo e($article->published_at->format('d M Y')); ?>

                    <?php else: ?>
                        <?php echo e($article->created_at->format('d M Y')); ?>

                    <?php endif; ?>
                </span>
                <span class="flex items-center transition-colors duration-200 hover:text-blue-500">
                    <i class="far fa-eye mr-2"></i>
                    <?php echo e($article->getViewsCount() ?? 0); ?> vues
                </span>
                <span class="flex items-center transition-colors duration-200 hover:text-blue-500">
                    <i class="far fa-comment mr-2"></i>
                    <?php echo e($article->comments->count()); ?> commentaires
                </span>
            </div>

            <?php if($article->video): ?>
                <div class="mb-8">
                    <?php if (isset($component)) { $__componentOriginald7f86aa0c577069eed71ec51c2a540ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7f86aa0c577069eed71ec51c2a540ae = $attributes; } ?>
<?php $component = App\View\Components\VideoFrame::resolve(['url' => ''.e($article->video->url).'','title' => ''.e($article->video->title).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('video-frame'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\VideoFrame::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'rounded-2xl overflow-hidden shadow-lg']); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7f86aa0c577069eed71ec51c2a540ae)): ?>
<?php $attributes = $__attributesOriginald7f86aa0c577069eed71ec51c2a540ae; ?>
<?php unset($__attributesOriginald7f86aa0c577069eed71ec51c2a540ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7f86aa0c577069eed71ec51c2a540ae)): ?>
<?php $component = $__componentOriginald7f86aa0c577069eed71ec51c2a540ae; ?>
<?php unset($__componentOriginald7f86aa0c577069eed71ec51c2a540ae); ?>
<?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Content -->
            <div class="prose dark:prose-invert max-w-none mb-12 text-lg leading-relaxed" x-data x-init="
                document.querySelectorAll('.prose img').forEach(img => {
                    img.classList.add('mx-auto', 'rounded-2xl', 'shadow-xl', 'transition-all', 'duration-300', 'hover:shadow-2xl', 'hover:scale-[1.02]');
                    img.style.maxWidth = '900px';
                    img.style.width = '100%';
                    img.style.height = 'auto';
                    img.style.display = 'block';
                    img.removeAttribute('width');
                    img.removeAttribute('height');
                })
            ">
                <?php echo $article->content; ?>

            </div>

            <!-- Share Buttons -->
            <div class="flex items-center gap-6 py-8 border-t border-gray-200 dark:border-gray-700">
                <span class="text-gray-700 dark:text-gray-300 font-medium">Partager :</span>
                <a href="#" class="text-2xl text-blue-500 hover:text-blue-600 dark:text-blue-400 transition-colors duration-200 hover:scale-110 transform">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="text-2xl text-blue-700 hover:text-blue-800 dark:text-blue-400 transition-colors duration-200 hover:scale-110 transform">
                    <i class="fab fa-facebook"></i>
                </a>
                <a href="#" class="text-2xl text-green-600 hover:text-green-700 dark:text-green-400 transition-colors duration-200 hover:scale-110 transform">
                    <i class="fab fa-whatsapp"></i>
                </a>
            </div>
        </div>
    </article>

    <!-- Comments Section -->
    <div class="mt-16 bg-white dark:bg-gray-800 rounded-3xl shadow-xl p-10">
        <h2 class="text-3xl font-bold mb-10 text-gray-900 dark:text-white">Commentaires</h2>

        <!-- Comment Form -->
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comment-form', ['postId' => $article->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2443176092-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        <!-- Comments List -->
        <div class="mt-8">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comments', ['articleId' => $article->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2443176092-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\fenohery\mjstack\mj-stack\resources\views\blog\show.blade.php ENDPATH**/ ?>