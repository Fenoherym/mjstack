<?php $__env->startSection('title'); ?>
    Accueil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section avec Code Typing -->
    <section class="pt-32 pb-16 px-4 bg-gradient-to-b from-blue-50 to-white dark:from-gray-800 dark:to-gray-900">
        <div class="container mx-auto">
            <div class="grid md:grid-cols-2 gap-8 items-center">
                <div class="text-left">
                    <h1 class="text-4xl md:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
                        Code, Apprends, <span class="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Partage</span>
                    </h1>
                    <p class="text-xl text-gray-600 dark:text-gray-300 mb-8">
                        Explorez le monde du développement web à travers mes articles et tutoriels.
                    </p>
                    <div class="relative max-w-xl">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('search-posts', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-13103715-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>

                <div class="relative">
                    <div class="bg-gray-900 dark:bg-gray-800 rounded-lg shadow-xl p-4 font-mono text-sm">
                        <div class="flex items-center gap-2 mb-4">
                            <div class="w-3 h-3 rounded-full bg-red-500"></div>
                            <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                            <div class="w-3 h-3 rounded-full bg-green-500"></div>
                        </div>
                        <div class="text-gray-100">
                            <span id="typing-text"></span>
                            <span class="typing-cursor animate-pulse">|</span>
                        </div>
                    </div>
                    <div
                        class="absolute -z-10 top-10 right-10 w-full h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg transform rotate-3">
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Featured Articles -->
    <section class="container mx-auto px-4 py-12">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Derniers Articles</h2>
            <a href="<?php echo e(route('blog.index')); ?>" class="text-blue-600 dark:text-blue-400 hover:text-blue-700 flex items-center gap-2">
                Voir tous les articles
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article
                    class="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg card-scale border border-gray-100 dark:border-gray-700">
                    <?php if($post->featured_image): ?>
                        <div class="relative h-56">
                            <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" alt="<?php echo e($post->title); ?>"
                                class="w-full h-full object-cover">
                            <div class="absolute top-4 right-4">
                                <span class="bg-blue-500 text-white px-3 py-1 rounded-full text-sm">
                                    <?php echo e($post->published_at->format('d M Y')); ?>

                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="p-6">
                        <div class="flex items-center space-x-2 mb-4">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span
                                    class="text-sm px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
                                    <?php echo e($tag->name); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <h2 class="text-xl font-bold mb-3 text-gray-900 dark:text-white"><?php echo e($post->title); ?></h2>
                        <p class="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3"><?php echo e($post->excerpt); ?></p>
                        <div class="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-gray-700">
                            <div class="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                                <span><i class="far fa-comment mr-1"></i> <?php echo e($post->comments->count()); ?></span>
                                <span><i class="far fa-eye mr-1"></i> <?php echo e($post->getViewsCount()); ?></span>
                            </div>
                            <a href="<?php echo e(route('blog.show', $post)); ?>"
                                class="inline-flex items-center space-x-2 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                                <span>Lire la suite</span>
                                <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <!-- Latest YouTube Video -->
    <?php if (isset($component)) { $__componentOriginald7f86aa0c577069eed71ec51c2a540ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald7f86aa0c577069eed71ec51c2a540ae = $attributes; } ?>
<?php $component = App\View\Components\VideoFrame::resolve(['url' => ''.e($last_video->url).'','title' => 'Ma dernière vidéo'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('video-frame'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\VideoFrame::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald7f86aa0c577069eed71ec51c2a540ae)): ?>
<?php $attributes = $__attributesOriginald7f86aa0c577069eed71ec51c2a540ae; ?>
<?php unset($__attributesOriginald7f86aa0c577069eed71ec51c2a540ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7f86aa0c577069eed71ec51c2a540ae)): ?>
<?php $component = $__componentOriginald7f86aa0c577069eed71ec51c2a540ae; ?>
<?php unset($__componentOriginald7f86aa0c577069eed71ec51c2a540ae); ?>
<?php endif; ?>
    
    <!-- Tech Stack & Tools -->
    <section class="py-16 bg-gray-50 dark:bg-gray-800/50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white mb-4">Technologies & Outils</h2>
            <p class="text-center text-gray-600 dark:text-gray-300 mb-12 max-w-2xl mx-auto">
                Voici les technologies et outils que j'utilise quotidiennement et que je recommande
            </p>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8">
                <div class="flex flex-col items-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg transition-transform hover:-translate-y-1">
                    <i class="fab fa-laravel text-5xl text-red-500 mb-4"></i>
                    <h3 class="font-semibold text-gray-900 dark:text-white">Laravel</h3>
                </div>
                <div class="flex flex-col items-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg transition-transform hover:-translate-y-1">
                    <i class="fab fa-vuejs text-5xl text-green-500 mb-4"></i>
                    <h3 class="font-semibold text-gray-900 dark:text-white">Vue.js</h3>
                </div>
                <div class="flex flex-col items-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg transition-transform hover:-translate-y-1">
                    <i class="fab fa-react text-5xl text-blue-400 mb-4"></i>
                    <h3 class="font-semibold text-gray-900 dark:text-white">React</h3>
                </div>
                <div class="flex flex-col items-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg transition-transform hover:-translate-y-1">
                    <svg class="w-12 h-12 mb-4 text-sky-500" viewBox="0 0 24 24" fill="currentColor">
                        <path fill-rule="evenodd" d="M12 6.036c-2.667 0-4.333 1.325-5 3.976 1-1.325 2.167-1.822 3.5-1.491.761.189 1.305.738 1.91 1.345 0.98.979 2.112 2.114 4.59 2.114 2.667 0 4.333-1.325 5-3.976-1 1.325-2.166 1.822-3.5 1.491-.761-.189-1.305-.738-1.91-1.345-.98-.979-2.112-2.114-4.59-2.114zM7 12.036c-2.667 0-4.333 1.325-5 3.976 1-1.326 2.167-1.822 3.5-1.491.761.189 1.305.738 1.91 1.345.98.979 2.112 2.114 4.59 2.114 2.667 0 4.333-1.325 5-3.976-1 1.325-2.166 1.822-3.5 1.491-.761-.189-1.305-.738-1.91-1.345-.98-.979-2.112-2.114-4.59-2.114z"/>
                    </svg>
                    <h3 class="font-semibold text-gray-900 dark:text-white">Tailwind CSS</h3>
                </div>
            </div>                
            </div>
        </div>
    </section>

    
    


    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('partial-js'); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/js/codewritter.js']); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="MJ Stack - Blog technique et tutoriels sur le développement web, Laravel, Vue.js, React et Tailwind CSS">
    <meta name="author" content="MJ Stack">
    <meta name="keywords" content="Laravel, Vue.js, React, Tailwind CSS, développement web, tutoriels">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mjstackc/mj-stack/resources/views/welcome.blade.php ENDPATH**/ ?>