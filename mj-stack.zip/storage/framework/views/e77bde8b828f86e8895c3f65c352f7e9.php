<div class="space-y-8">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex gap-4 p-6 rounded-xl bg-gray-50 dark:bg-gray-700/50">
            <div class="flex-shrink-0">
                <div class="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                    <span class="text-blue-600 dark:text-blue-300 text-lg font-bold">
                        <?php echo e(substr($comment->author_name, 0, 1)); ?>

                    </span>
                </div>
            </div>
            <div class="flex-grow">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="font-semibold text-gray-900 dark:text-white"><?php echo e($comment->author_name); ?></h3>
                    <span class="text-sm text-gray-500 dark:text-gray-400">
                        <?php echo e($comment->created_at->diffForHumans()); ?>

                    </span>
                </div>
                <p class="text-gray-600 dark:text-gray-300"><?php echo e($comment->content); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /home/mjstackc/mj-stack/resources/views/livewire/comments.blade.php ENDPATH**/ ?>