<?php
    use Rawilk\FilamentQuill\Enums\ToolbarButton;

    $textColors = $getTextColors();
    $backgroundColors = $getBackgroundColors();
    $placeholders = $getPlaceholders();
?>

<!--[if BLOCK]><![endif]--><?php if($hasStickyToolbar): ?>
    
    <div x-ref="stickyToolbar" class="w-0 h-0" wire:ignore></div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<div
    id="quill-toolbar-<?php echo e($id); ?>"
    x-ref="toolbar"
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'fi-quill-toolbar',
    ]); ?>"
    wire:ignore
>
    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::Font, ToolbarButton::Size])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Font)): ?>
                <select class="ql-font" title="<?php echo e(__('filament-quill::quill.toolbar.font')); ?>">
                    <!--[if BLOCK]><![endif]--><?php if(is_array($fonts) && count($fonts)): ?>
                        <option></option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mapFontName($font)); ?>" data-label="<?php echo e($font); ?>"></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Size)): ?>
                <select class="ql-size" title="<?php echo e(__('filament-quill::quill.toolbar.size')); ?>">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fontSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fontSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fontSize); ?>" data-label="<?php echo e($fontSize); ?>" <?php if($fontSize === $defaultFontSize): echo 'selected'; endif; ?>></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::Bold, ToolbarButton::Italic, ToolbarButton::Underline, ToolbarButton::Strike])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Bold)): ?>
                <button class="ql-bold" title="<?php echo e(__('filament-quill::quill.toolbar.bold')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Italic)): ?>
                <button class="ql-italic" title="<?php echo e(__('filament-quill::quill.toolbar.italic')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Underline)): ?>
                <button class="ql-underline" title="<?php echo e(__('filament-quill::quill.toolbar.underline')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Strike)): ?>
                <button class="ql-strike" title="<?php echo e(__('filament-quill::quill.toolbar.strike')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::TextColor, ToolbarButton::BackgroundColor])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::TextColor)): ?>
                <select class="ql-color" title="<?php echo e(__('filament-quill::quill.toolbar.color')); ?>">
                    <!--[if BLOCK]><![endif]--><?php if(is_array($textColors) && count($textColors)): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $textColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($color); ?>"></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::BackgroundColor)): ?>
                <select class="ql-background" title="<?php echo e(__('filament-quill::quill.toolbar.background')); ?>">
                    <!--[if BLOCK]><![endif]--><?php if(is_array($backgroundColors) && count($backgroundColors)): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $backgroundColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($color); ?>"></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Scripts)): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <button class="ql-script" value="sub" title="<?php echo e(__('filament-quill::quill.toolbar.sub')); ?>"></button>
            <button class="ql-script" value="super" title="<?php echo e(__('filament-quill::quill.toolbar.super')); ?>"></button>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::BlockQuote, ToolbarButton::CodeBlock])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::BlockQuote)): ?>
                <button class="ql-blockquote" title="<?php echo e(__('filament-quill::quill.toolbar.blockquote')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::CodeBlock)): ?>
                <button class="ql-code-block" title="<?php echo e(__('filament-quill::quill.toolbar.code')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::OrderedList, ToolbarButton::UnorderedList, ToolbarButton::Indent])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::OrderedList)): ?>
                <button class="ql-list" value="ordered" title="<?php echo e(__('filament-quill::quill.toolbar.ol')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::UnorderedList)): ?>
                <button class="ql-list" value="bullet" title="<?php echo e(__('filament-quill::quill.toolbar.ul')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Indent)): ?>
                <button class="ql-indent" value="-1" title="<?php echo e(__('filament-quill::quill.toolbar.outdent')); ?>"></button>
                <button class="ql-indent" value="+1" title="<?php echo e(__('filament-quill::quill.toolbar.indent')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::TextAlign)): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <select class="ql-align" title="<?php echo e(__('filament-quill::quill.toolbar.text_align')); ?>">
                 <option selected="selected"></option>
                 <option value="center"></option>
                 <option value="right"></option>
                 <option value="justify"></option>
            </select>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::Link, ToolbarButton::Image])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Link)): ?>
                <button class="ql-link" title="<?php echo e(__('filament-quill::quill.toolbar.link')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Image)): ?>
                <button class="ql-image" title="<?php echo e(__('filament-quill::quill.toolbar.image')); ?>"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::ClearFormat)): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <button class="ql-clean" title="<?php echo e(__('filament-quill::quill.toolbar.clean')); ?>"></button>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton([ToolbarButton::Undo, ToolbarButton::Redo])): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Undo)): ?>
                <button class="ql-undo" title="<?php echo e(__('filament-quill::quill.toolbar.undo')); ?>">
                    <svg
                        class="w-4 h-4 dark:fill-current"
                        aria-hidden="true"
                        focusable="false"
                        data-prefix="fas"
                        data-icon="rotate-left"
                        role="img"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 512 512"
                    >
                        <path
                            fill="currentColor"
                            d="M480 256c0 123.4-100.5 223.9-223.9 223.9c-48.84 0-95.17-15.58-134.2-44.86c-14.12-10.59-16.97-30.66-6.375-44.81c10.59-14.12 30.62-16.94 44.81-6.375c27.84 20.91 61 31.94 95.88 31.94C344.3 415.8 416 344.1 416 256s-71.69-159.8-159.8-159.8c-37.46 0-73.09 13.49-101.3 36.64l45.12 45.14c17.01 17.02 4.955 46.1-19.1 46.1H35.17C24.58 224.1 16 215.5 16 204.9V59.04c0-24.04 29.07-36.08 46.07-19.07l47.6 47.63C149.9 52.71 201.5 32.11 256.1 32.11C379.5 32.11 480 132.6 480 256z"
                        ></path>
                    </svg>
                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Redo)): ?>
                <button class="ql-redo" title="<?php echo e(__('filament-quill::quill.toolbar.redo')); ?>">
                    <svg
                        class="w-4 h-4 dark:fill-current"
                        aria-hidden="true"
                        focusable="false"
                        data-prefix="fas"
                        data-icon="rotate-right"
                        role="img"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 512 512"
                    >
                        <path
                            fill="currentColor"
                            d="M468.9 32.11c13.87 0 27.18 10.77 27.18 27.04v145.9c0 10.59-8.584 19.17-19.17 19.17h-145.7c-16.28 0-27.06-13.32-27.06-27.2c0-6.634 2.461-13.4 7.96-18.9l45.12-45.14c-28.22-23.14-63.85-36.64-101.3-36.64c-88.09 0-159.8 71.69-159.8 159.8S167.8 415.9 255.9 415.9c73.14 0 89.44-38.31 115.1-38.31c18.48 0 31.97 15.04 31.97 31.96c0 35.04-81.59 70.41-147 70.41c-123.4 0-223.9-100.5-223.9-223.9S132.6 32.44 256 32.44c54.6 0 106.2 20.39 146.4 55.26l47.6-47.63C455.5 34.57 462.3 32.11 468.9 32.11z"
                        ></path>
                    </svg>
                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if(is_array($placeholders) && count($placeholders)): ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => ['style' => \Illuminate\Support\Arr::toCssStyles([
                '--ql-button-label: ' . \Illuminate\Support\Js::from($getPlaceholderButtonLabel())
            ])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssStyles([
                '--ql-button-label: ' . \Illuminate\Support\Js::from($getPlaceholderButtonLabel())
            ]))]); ?>
            <select class="ql-placeholders">
                
                <option></option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $placeholders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placeholder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($placeholder); ?>"></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getCustomToolbarButtons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal2f9bd5e8de0173f5295763f06b66d641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-quill::components.toolbar-group','data' => ['class' => 'ql-formats-custom','style' => \Illuminate\Support\Arr::toCssStyles([
                '--ql-button-label: ' . \Illuminate\Support\Js::from($button['label']),
            ])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-quill::toolbar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ql-formats-custom','style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssStyles([
                '--ql-button-label: ' . \Illuminate\Support\Js::from($button['label']),
            ]))]); ?>
            <?php
                $options = $button['options'] ?? [];
            ?>

            <!--[if BLOCK]><![endif]--><?php if(filled($options)): ?>
                <select
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        "ql-{$name}",
                        'ql-custom',
                        'ql-not-selectable' => ! $button['showSelected'],
                    ]); ?>"
                >
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($optionValue); ?>"><?php echo e($optionLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php else: ?>
                <button class="ql-<?php echo e($name); ?> ql-button ql-custom"></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $attributes = $__attributesOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__attributesOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641)): ?>
<?php $component = $__componentOriginal2f9bd5e8de0173f5295763f06b66d641; ?>
<?php unset($__componentOriginal2f9bd5e8de0173f5295763f06b66d641); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($hasToolbarButton(ToolbarButton::Header)): ?>
        <select class="ql-header" title="<?php echo e(__('filament-quill::quill.toolbar.header')); ?>">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($header); ?>" data-label="<?php echo e($header); ?>" <?php if($header === $defaultHeaderSize): echo 'selected'; endif; ?>></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /home/mjstackc/mj-stack/vendor/rawilk/filament-quill/src/../resources/views/partials/toolbar.blade.php ENDPATH**/ ?>